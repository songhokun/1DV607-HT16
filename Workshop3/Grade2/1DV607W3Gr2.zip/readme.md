#README

##Workshop 3 grade 2 submission
This programe is written in Java.

In order to run Java programme, JRE 1.8 (Java runtime environment) or higher is required.
If you have problem with setting up your IDE we have a runnable jar file which you can use to test the programme.
In order to execute the JAR file, enter command "java -jar _location of jar file_" on your terminal (command).
You can instead drag the file to console instead of writing the path of jar file.

By default we implemented Soft17Hit hitting rule with American new game strategy + player advantage winning rule.
We mean player advantage by letting player to be a winner on equal score.

If you want to test other strategy rules, you can modify the RulesFactory on the your IDE and compile the project.

Should you have questions contact to either,
1. Sarpreet Singh Buttar sb223ce [at] student.lnu.se
2. Songho Lee sl222xk [at] student.lnu.se

Enjoy the programme!

Växjö, October 31, 2016

Sarpreet Singh Buttar
Songho Lee.
